#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
# RRoot, 11/02/2016, Created starting template
# RLarge, 11/20/18, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

        #---- Data ----#

#Identify constants
dictfile = {} #A row of data separated into elements of a dictionary {Task,Priority}
lstTable = [] #A dictionary that acts as a 'table' of rows

strmenu = ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """) #display menu options

#strChoice = Capture the user option selection

        #---- Input/Output ----#

# User can see menu choices  (Step 2)
# and original items in txt file (Step 3)
# User can add new items (Step 4)
# User can remove an existing item (Step 5)
# User can save to file (Step 6)
# User can exit program (Step 7)

        #---- Processing ----#

#--Step 1--#

#Open and read existing file
file = open("C:\\_PythonClass\Assignment05\Module05\\ToDo.txt", "r")

#append values to a dictionary
for line in file:
    taskstr = line.strip("\n").split(",")[0]
    prioritystr = line.strip("\n:").split(",")[1]
    dictfile = {"Task": taskstr, "Priority": prioritystr}
    lstTable.append(dictfile)

#display data from text file
print("------- Current List -------")
for item in lstTable:
    print(item["Task"], ",", item["Priority"])
print("----------------------------")
file.close()

#--Step 2--#

#Display a menu of choices to the user
while(True):
    print(strmenu)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))

#--Step 3--#

    # Show the current items in the table
    if (strChoice.strip() == '1'):
        print("------- Current List -----")
        for item in lstTable:
            print(item["Task"], ",", item["Priority"])
        print("--------------------------")
        continue

#--Step 4--#

    #Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        task1 = (input("Enter a new Task: "))
        prior1 = (input("Enter the Priority: "))
        dictfile = {"Task": task1, "Priority": prior1}
        lstTable.append(dictfile)
        print("\n")
        print("------- Current List -----")
        for item in lstTable:
           print(item["Task"], ",", item["Priority"])
        print("--------------------------")

#--Step 5--#


    ##Remove a item from the list
    elif(strChoice == '3'):

        taskrem = input("New task to remove: ")
        count = 0
        for item in lstTable:
            for key, value in item.items():
                if value == taskrem:
                    del lstTable[count]
                    print("Your item has been deleted.")
            count = count + 1
            if value != taskrem:
                print("Item not deleted.")
                count = 0
                continue


#--Step 6--#

    #Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        file = open("toDo.txt", "w")
        for item in lstTable:
            file.write(item["Task"] + "," + item["Priority"] + "\n")
        file.close()
        print("data has been saved to ToDo.txt file.")
        file.close()

#--Step 7--#

    #break and exit program
    elif (strChoice == '5'):
        print("Program will now exit")
        break
